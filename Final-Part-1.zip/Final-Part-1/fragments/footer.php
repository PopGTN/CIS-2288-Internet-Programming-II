<footer class="bg-body-tertiary">
    <div class="container py-2">
        <small class="text-center fw-semibold">Bookorama Management System © <?= date("Y") ?></small>
    </div>
</footer>