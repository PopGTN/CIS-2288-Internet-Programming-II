<?php


require_once 'Classes/CisUtil.class.php';
CisUtil::autoload();

header("Location: addAlbum.php");

