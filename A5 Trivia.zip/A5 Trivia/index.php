<?php
Header("Location: trivia.php");